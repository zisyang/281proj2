/**
 * working with api in lambda
 * for testing purpose only
 */

module.exports = {
  "RDS_HOSTNAME" : "database-281.ciunuysgnwmp.us-west-1.rds.amazonaws.com",
  "RDS_USERNAME" : "admin",
  "RDS_PASSWORD" : "LRaOA05sEpntp2mXyo6d",
  "RDS_PORT" : "3306",
  "DATABASE" : "database281",
  "TABLE" : "files"
};
// JavaScript File
