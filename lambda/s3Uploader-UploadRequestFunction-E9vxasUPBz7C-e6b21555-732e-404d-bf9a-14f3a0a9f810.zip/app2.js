
const AWS = require('aws-sdk')
AWS.config.update({ region: process.env.AWS_REGION })
import { getSignedUrl } from "@aws-sdk/cloudfront-signer";

// Change this value to adjust the signed URL's expiration
const URL_EXPIRATION_SECONDS = 300

// Main Lambda entry point
exports.handler = async (event) => {
  return await getUploadURL(event)
}

const getUploadURL = async function(event) {
  const randomID = parseInt(Math.random() * 10000000)
  const Key = `${randomID}.jpg`

  // Get signed URL from S3
  const url = process.env.cfURL + "/" + Key;
  const keyPairId = process.env.PUBLIC_KEK;
  const privateKey = process.env.PRIVATE_KEY;
  // const signingParams = {
  //   url,
  //   process.env.PUBLIC_KEY,
  //   URL_EXPIRATION_SECONDS,
  //   process.env.PRIVATE_KEY
  // };

  // console.log('signingParams>>');
  // console.log(signingParams);
  const uploadURL = getSignedUrl({
    url,
    keyPairId,
    URL_EXPIRATION_SECONDS,
    privateKey
  });

  return JSON.stringify({
    uploadTime: Date.now(),
    uploadURL: uploadURL
    // Key
  })
}