/**
 * working with api in lambda
 * for testing purpose only
 */

module.exports = {
  "UploadBucket" : "s3uploader-s3uploadbucket-l63io50vx6tm",
  "CloudfrontDDN" : "https://d1tcdrtxgiif3a.cloudfront.net"
};
// JavaScript File
