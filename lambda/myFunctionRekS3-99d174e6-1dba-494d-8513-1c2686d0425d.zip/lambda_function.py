# import json

# def lambda_handler(event, context):
#     # TODO implement
#     return {
#         'statusCode': 200,
#         'body': json.dumps('Hello from Lambda!')
#     }

import json
import boto3

def lambda_handler(event, context):
    
    # print(event['key1'])
    bucket="s3uploader-s3uploadbucket-l63io50vx6tm"
    # photo="852657.jpg"
    photo=event['Image']
    
    client=boto3.client('rekognition')

    #process using S3 object
    
    response = client.detect_labels(Image={'S3Object': {'Bucket': bucket, 'Name': photo}},
        MaxLabels=10)    

    #Get the custom labels
    labels=response['Labels']
    
    return {
        'statusCode': 200,
        'body': json.dumps(labels)
    }  